import { useEffect, useState } from "react";
import API from "../api";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend
);

export default function OrdersPage() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    API.get("/orders/1")
      .then((res) => setOrders(res.data))
      .catch((err) => console.error("❌ Failed to load orders:", err));
  }, []);

  const chartData = {
    labels: orders.map((o) => new Date(o.createdAt).toLocaleDateString()),
    datasets: [
      {
        label: "Revenue",
        data: orders.map((o) => o.total),
        fill: false,
        borderColor: "#3b82f6",
        tension: 0.2,
      },
    ],
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Orders</h1>

      <div className="bg-white rounded-xl shadow-md p-4 mb-6">
        <h2 className="text-xl font-semibold mb-4">Revenue Over Time</h2>
        <Line data={chartData} />
      </div>

      <table className="w-full bg-white rounded-xl shadow-md">
        <thead>
          <tr className="border-b bg-gray-100">
            <th className="p-3 text-left">Order #</th>
            <th className="p-3 text-left">Total</th>
            <th className="p-3 text-left">Status</th>
            <th className="p-3 text-left">Date</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((o) => (
            <tr key={o.id} className="border-b hover:bg-gray-50">
              <td className="p-3">{o.id}</td>
              <td className="p-3">${o.total}</td>
              <td className="p-3">{o.status}</td>
              <td className="p-3">
                {new Date(o.createdAt).toLocaleDateString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
