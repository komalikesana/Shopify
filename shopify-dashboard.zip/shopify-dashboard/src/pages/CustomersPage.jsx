import { useEffect, useState } from "react";
import API from "../api";

export default function CustomersPage() {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    API.get("/customers/1")
      .then((res) => setCustomers(res.data))
      .catch((err) => console.error("❌ Failed to load customers:", err));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Customers</h1>
      <table className="w-full bg-white rounded-xl shadow-md">
        <thead>
          <tr className="border-b bg-gray-100">
            <th className="p-3 text-left">Name</th>
            <th className="p-3 text-left">Email</th>
            <th className="p-3 text-left">Created At</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((c) => (
            <tr key={c.id} className="border-b hover:bg-gray-50">
              <td className="p-3">{c.name}</td>
              <td className="p-3">{c.email}</td>
              <td className="p-3">{new Date(c.createdAt).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
