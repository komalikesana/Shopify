import { useEffect, useState } from "react";
import API from "../api";

export default function ProductsPage() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
  API.get("/products/1")
    .then((res) => {
      console.log("✅ API Response from backend:", res.data);
      setProducts(res.data);
    })
    .catch((err) => {
      console.error("❌ API Error:", err.message);
    });
}, []);

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Products</h1>

      {products.length === 0 ? (
        <p className="text-gray-500 text-center">No products found.</p>
      ) : (
        <table className="w-full bg-white rounded-xl shadow-md">
          <thead>
            <tr className="border-b bg-gray-100">
              <th className="p-3 text-left">Shopify ID</th>
              <th className="p-3 text-left">Title</th>
              <th className="p-3 text-left">Price</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-b hover:bg-gray-50">
                <td className="p-3">{p.shopifyId}</td>
                <td className="p-3">{p.title}</td>
                <td className="p-3">₹{p.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
