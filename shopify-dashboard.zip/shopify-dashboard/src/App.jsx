import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "./api";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export default function App() {
  const [metrics, setMetrics] = useState(null);
  const navigate = useNavigate();
  const tenantId = 1;

  useEffect(() => {
    API.get(`/metrics/${tenantId}`)
      .then((res) => {
        console.log("✅ Metrics response:", res.data);
        setMetrics(res.data);
      })
      .catch((err) => console.error("❌ Error fetching metrics:", err.message));
  }, []);

  if (!metrics)
    return <div className="p-10 text-xl text-center">Loading dashboard...</div>;

  const chartData = {
    labels: ["Customers", "Products", "Orders"],
    datasets: [
      {
        label: "Counts",
        data: [metrics.customers, metrics.products, metrics.orders],
        backgroundColor: ["#3b82f6", "#10b981", "#f59e0b"],
        borderRadius: 8,
      },
    ],
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-3xl font-bold mb-6 text-center">
        Shopify-Like Dashboard
      </h1>

      {/* Clickable Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
        <div
          onClick={() => navigate("/customers")}
          className="bg-white rounded-xl shadow-md p-6 text-center cursor-pointer hover:shadow-lg transition"
        >
          <h2 className="text-gray-500 text-lg">Customers</h2>
          <p className="text-3xl font-bold text-blue-500">{metrics.customers}</p>
        </div>

        <div
          onClick={() => navigate("/products")}
          className="bg-white rounded-xl shadow-md p-6 text-center cursor-pointer hover:shadow-lg transition"
        >
          <h2 className="text-gray-500 text-lg">Products</h2>
          <p className="text-3xl font-bold text-green-500">{metrics.products}</p>
        </div>

        <div
          onClick={() => navigate("/orders")}
          className="bg-white rounded-xl shadow-md p-6 text-center cursor-pointer hover:shadow-lg transition"
        >
          <h2 className="text-gray-500 text-lg">Orders</h2>
          <p className="text-3xl font-bold text-yellow-500">{metrics.orders}</p>
        </div>
      </div>

      {/* Overview Chart */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-semibold mb-4">Store Overview</h2>
        <Bar data={chartData} />
      </div>
    </div>
  );
}
