import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:3000", // ✅ must match your backend server
});

export default API;
