const dotenv = require("dotenv");
const express = require("express");
const axios = require("axios");
const { PrismaClient } = require("@prisma/client");


dotenv.config();

const prisma = new PrismaClient();
const app = express();

// Shopify API Client
const shopifyClient = axios.create({
  baseURL: `https://${process.env.SHOPIFY_STORE_URL}/admin/api/2024-07`,
  headers: {
    "X-Shopify-Access-Token": process.env.SHOPIFY_ACCESS_TOKEN,
    "Content-Type": "application/json",
  },
});

// Health Check Route
app.get("/", (req, res) => {
  res.json({ message: "Backend is running!" });
});

// ✅ Test Shopify Connection
app.get("/test-shopify", async (req, res) => {
  try {
    const customers = await shopifyClient.get("/customers.json");
    const products = await shopifyClient.get("/products.json");
    const orders = await shopifyClient.get("/orders.json");

    res.json({
      message: "Shopify connection successful",
      customerCount: customers.data.customers.length,
      productCount: products.data.products.length,
      orderCount: orders.data.orders.length,
    });
  } catch (err) {
    console.error("Shopify API Error:", err.response?.data || err.message);
    res.status(500).json({ error: "Failed to connect to Shopify" });
  }
});

// ✅ Ingest Customers
app.get("/ingest/customers/:tenantId", async (req, res) => {
  const { tenantId } = req.params;
  try {
    const response = await shopifyClient.get("/customers.json");
    const customers = response.data.customers;

    for (const c of customers) {
      await prisma.customer.upsert({
        where: { shopifyId: String(c.id) },
        update: {
          email: c.email,
          firstName: c.first_name,
          lastName: c.last_name,
          tenantId: parseInt(tenantId),
        },
        create: {
          shopifyId: String(c.id),
          email: c.email,
          firstName: c.first_name,
          lastName: c.last_name,
          tenantId: parseInt(tenantId),
        },
      });
    }

    res.json({ message: `✅ ${customers.length} customers ingested successfully` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to ingest customers" });
  }
});

// ✅ Ingest Products
app.get("/ingest/products/:tenantId", async (req, res) => {
  const { tenantId } = req.params;
  try {
    const response = await shopifyClient.get("/products.json");
    const products = response.data.products;

    for (const p of products) {
      await prisma.product.upsert({
        where: { shopifyId: String(p.id) },
        update: {
          title: p.title,
          price: parseFloat(p.variants[0].price),
          tenantId: parseInt(tenantId),
        },
        create: {
          shopifyId: String(p.id),
          title: p.title,
          price: parseFloat(p.variants[0].price),
          tenantId: parseInt(tenantId),
        },
      });
    }

    res.json({ message: `✅ ${products.length} products ingested successfully` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to ingest products" });
  }
});

// ✅ Ingest Orders
app.get("/ingest/orders/:tenantId", async (req, res) => {
  const { tenantId } = req.params;
  try {
    const response = await shopifyClient.get("/orders.json");
    const orders = response.data.orders;

    for (const o of orders) {
      await prisma.order.upsert({
        where: { shopifyId: String(o.id) },
        update: {
          total: parseFloat(o.total_price),
          createdAt: new Date(o.created_at),
          tenantId: parseInt(tenantId),
        },
        create: {
          shopifyId: String(o.id),
          total: parseFloat(o.total_price),
          createdAt: new Date(o.created_at),
          tenantId: parseInt(tenantId),
        },
      });
    }

    res.json({ message: `✅ ${orders.length} orders ingested successfully` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to ingest orders" });
  }
});

app.listen(3000, () => {
  console.log("✅ Server running on http://localhost:3000");
});


// Get total counts
app.get("/metrics/:tenantId", async (req, res) => {
  const { tenantId } = req.params;
  try {
    const customers = await prisma.customer.count({ where: { tenantId: Number(tenantId) } });
    const products = await prisma.product.count({ where: { tenantId: Number(tenantId) } });
    const orders = await prisma.order.findMany({ where: { tenantId: Number(tenantId) } });

    const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);

    res.json({ customers, products, orders: orders.length, totalRevenue });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch metrics" });
  }
});

app.get("/metrics/:tenantId", async (req, res) => {
  const { tenantId } = req.params;
  try {
    const customersCount = await prisma.customer.count({
      where: { tenantId: parseInt(tenantId) },
    });

    const productsCount = await prisma.product.count({
      where: { tenantId: parseInt(tenantId) },
    });

    const orders = await prisma.order.findMany({
      where: { tenantId: parseInt(tenantId) },
    });

    const ordersCount = orders.length;
    const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);

    res.json({
      customers: customersCount,
      products: productsCount,
      orders: ordersCount,
      totalRevenue,
    });
  } catch (error) {
    console.error("❌ Failed to fetch metrics:", error.message);
    res.status(500).json({ error: "Failed to fetch metrics" });
  }
});

app.get("/customers/:tenantId", async (req, res) => {
  const { tenantId } = req.params;
  const customers = await prisma.customer.findMany({
    where: { tenantId: parseInt(tenantId) },
  });
  res.json(customers);
});

app.get("/products/:tenantId", async (req, res) => {
  const { tenantId } = req.params;
  const products = await prisma.product.findMany({
    where: { tenantId: parseInt(tenantId) },
  });
  res.json(products);
});

app.get("/orders/:tenantId", async (req, res) => {
  const { tenantId } = req.params;
  const orders = await prisma.order.findMany({
    where: { tenantId: parseInt(tenantId) },
  });
  res.json(orders);
});
